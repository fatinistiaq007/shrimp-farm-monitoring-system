<?php  
 //filter.php  
 if(isset($_POST["from_date"], $_POST["to_date"]))  
 {  
      $connect = mysqli_connect("localhost", "root", "", "testing");  
      $output = '';  
      $query = "  
           SELECT * FROM customer  
           WHERE date BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'  
      ";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
           <table class="table table-bordered">  
                <tr>  
							   <th width="5%">ID</th>  
                               <th width="10%">Temperature</th>  
                               <th width="10%">Ph</th>  
                               <th width="10%">Turbidity</th> 
							   <th width="10%">Uv</th>  
                               <th width="10%">Date</th>  
                </tr>  
      ';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
							   <td><?php echo $row["id"]; ?></td>  
                               <td><?php echo $row["temp"]; ?></td>  
                               <td><?php echo $row["ph"]; ?></td>  
                               <td><?php echo $row["turb"]; ?></td>
							   <td><?php echo $row["uv"]; ?></td>  							   
                               <td><?php echo $row["date"]; ?></td>  
                     </tr>  
                ';  
           }  
      }  
      else  
      {  
           $output .= '  
                <tr>  
                     <td colspan="6">No Data Found</td>  
                </tr>  
           ';  
      }  
      $output .= '</table>';  
      echo $output;  
 }  
 ?>
